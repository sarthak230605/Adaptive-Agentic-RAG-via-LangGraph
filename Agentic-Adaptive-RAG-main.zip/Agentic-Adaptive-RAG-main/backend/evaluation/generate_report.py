import json
import math
from pathlib import Path
from typing import Any, Dict


PROJECT_ROOT = Path(__file__).resolve().parent.parent

BENCHMARK_RESULTS_FILE = (
    PROJECT_ROOT
    / "evaluation"
    / "benchmark_results.json"
)

RAGAS_RESULTS_FILE = (
    PROJECT_ROOT
    / "evaluation"
    / "ragas_results.json"
)

FINAL_REPORT_FILE = (
    PROJECT_ROOT
    / "evaluation"
    / "final_report.json"
)


def load_json(
    path: Path,
) -> Dict[str, Any]:

    if not path.exists():
        raise FileNotFoundError(
            f"Required evaluation file not found: {path}"
        )

    with path.open(
        "r",
        encoding="utf-8",
    ) as file:
        return json.load(file)


def is_valid_number(
    value: Any,
) -> bool:

    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(float(value))
    )


def calculate_deterministic_answer_quality(
    benchmark_results: Dict[str, Any],
) -> Dict[str, Any]:

    results = benchmark_results.get(
        "results",
        [],
    )

    evaluated = 0
    passed = 0
    question_results = []

    for result in results:

        if result.get("error"):
            continue

        if "answer_contains_expected" not in result:
            continue

        evaluated += 1

        passed_question = bool(
            result.get(
                "answer_contains_expected",
                False,
            )
        )

        if passed_question:
            passed += 1

        question_results.append(
            {
                "question": result.get(
                    "question",
                    "",
                ),
                "passed": passed_question,
            }
        )

    rate = (
        passed / evaluated
        if evaluated
        else 0.0
    )

    return {
        "evaluated_questions": evaluated,
        "passed_questions": passed,
        "rate": rate,
        "question_results": question_results,
    }


def build_report() -> Dict[str, Any]:

    benchmark = load_json(
        BENCHMARK_RESULTS_FILE
    )

    ragas = load_json(
        RAGAS_RESULTS_FILE
    )

    benchmark_summary = benchmark.get(
        "summary",
        {},
    )

    ragas_summary = ragas.get(
        "summary",
        {},
    )

    deterministic_quality = (
        calculate_deterministic_answer_quality(
            benchmark
        )
    )

    ragas_faithfulness = (
        ragas_summary.get(
            "faithfulness"
        )
    )

    ragas_answer_relevancy = (
        ragas_summary.get(
            "answer_relevancy"
        )
    )

    if not is_valid_number(
        ragas_answer_relevancy
    ):
        ragas_answer_relevancy = None

    report = {
        "project": "Agentic-Adaptive-RAG",
        "evaluation_version": "4.3",
        "benchmark": {
            "questions_evaluated": benchmark_summary.get(
                "questions_evaluated",
                0,
            ),
            "successful_questions": benchmark_summary.get(
                "successful_questions",
                0,
            ),
            "benchmark_failures": benchmark_summary.get(
                "benchmark_failures",
                0,
            ),
            "errors": benchmark_summary.get(
                "errors",
                0,
            ),
            "rate_limited": benchmark_summary.get(
                "rate_limited",
                0,
            ),
            "routing_accuracy": benchmark_summary.get(
                "routing_accuracy",
                0.0,
            ),
            "grounded_answer_rate": benchmark_summary.get(
                "grounded_answer_rate",
                0.0,
            ),
            "answer_quality_rate": benchmark_summary.get(
                "answer_quality_rate",
                0.0,
            ),
            "average_local_retrieval_rate": benchmark_summary.get(
                "average_local_retrieval_rate",
                0.0,
            ),
            "average_latency_seconds": benchmark_summary.get(
                "average_latency_seconds",
                0.0,
            ),
            "average_retries": benchmark_summary.get(
                "average_retries",
                0.0,
            ),
            "overall_pass_rate": benchmark_summary.get(
                "overall_pass_rate",
                0.0,
            ),
        },
        "deterministic_evaluation": {
            "description": (
                "Uses deterministic answer-quality "
                "assertions from the benchmark runner."
            ),
            **deterministic_quality,
        },
        "ragas": {
            "metrics_evaluated": [
                "faithfulness",
                "answer_relevancy",
            ],
            "faithfulness": (
                ragas_faithfulness
                if is_valid_number(
                    ragas_faithfulness
                )
                else None
            ),
            "answer_relevancy": (
                ragas_answer_relevancy
            ),
            "answer_relevancy_status": (
                "unavailable"
                if ragas_answer_relevancy is None
                else "available"
            ),
            "answer_relevancy_note": (
                "The current Groq-compatible model "
                "configuration returned an API validation "
                "error for the RAGAS answer relevancy metric "
                "because the provider rejected an n parameter "
                "greater than 1."
                if ragas_answer_relevancy is None
                else ""
            ),
        },
    }

    return report


def print_report(
    report: Dict[str, Any],
) -> None:

    benchmark = report["benchmark"]

    deterministic = report[
        "deterministic_evaluation"
    ]

    ragas = report["ragas"]

    print()
    print("=" * 70)
    print(
        "AGENTIC ADAPTIVE RAG — "
        "CONSOLIDATED EVALUATION"
    )
    print("=" * 70)

    print()
    print("BENCHMARK")
    print("-" * 70)

    print(
        f"Questions evaluated:        "
        f"{benchmark['questions_evaluated']}"
    )

    print(
        f"Successful questions:       "
        f"{benchmark['successful_questions']}"
    )

    print(
        f"Benchmark failures:         "
        f"{benchmark['benchmark_failures']}"
    )

    print(
        f"Errors:                     "
        f"{benchmark['errors']}"
    )

    print(
        f"Rate-limited questions:     "
        f"{benchmark['rate_limited']}"
    )

    print(
        f"Routing accuracy:           "
        f"{benchmark['routing_accuracy']:.1%}"
    )

    print(
        f"Grounded answer rate:       "
        f"{benchmark['grounded_answer_rate']:.1%}"
    )

    print(
        f"Agent answer quality:       "
        f"{benchmark['answer_quality_rate']:.1%}"
    )

    print(
        f"Local retrieval relevance:  "
        f"{benchmark['average_local_retrieval_rate']:.1%}"
    )

    print(
        f"Average latency:             "
        f"{benchmark['average_latency_seconds']:.2f}s"
    )

    print(
        f"Average retries:             "
        f"{benchmark['average_retries']:.2f}"
    )

    print(
        f"Overall pass rate:           "
        f"{benchmark['overall_pass_rate']:.1%}"
    )

    print()
    print("DETERMINISTIC ANSWER EVALUATION")
    print("-" * 70)

    print(
        f"Questions evaluated:        "
        f"{deterministic['evaluated_questions']}"
    )

    print(
        f"Passed assertions:          "
        f"{deterministic['passed_questions']}"
    )

    print(
        f"Answer quality rate:        "
        f"{deterministic['rate']:.1%}"
    )

    print()
    print("RAGAS")
    print("-" * 70)

    faithfulness = ragas[
        "faithfulness"
    ]

    if faithfulness is not None:
        print(
            f"Faithfulness:               "
            f"{faithfulness:.1%}"
        )
    else:
        print(
            "Faithfulness:               "
            "unavailable"
        )

    answer_relevancy = ragas[
        "answer_relevancy"
    ]

    if answer_relevancy is not None:
        print(
            f"Answer relevancy:           "
            f"{answer_relevancy:.1%}"
        )
    else:
        print(
            "Answer relevancy:           "
            "unavailable"
        )

        print(
            "Reason: provider/API compatibility"
        )

    print()
    print("=" * 70)


def main() -> None:

    report = build_report()

    FINAL_REPORT_FILE.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with FINAL_REPORT_FILE.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            report,
            file,
            indent=2,
            ensure_ascii=False,
        )

    print_report(report)

    print()
    print(
        f"Final report saved to: "
        f"{FINAL_REPORT_FILE}"
    )


if __name__ == "__main__":
    main()